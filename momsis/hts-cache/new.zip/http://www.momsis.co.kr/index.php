<!-- <!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"> -->
<html>
<head>
<meta http-equiv="content-type" content="text/html; charset=euc-kr">
<title>������ 100% ����� ������ ������ �����ߴ����� �ᳪ��</title>
<link rel="stylesheet" href="./style.css" type="text/css">
</head>
<META NAME="DESCRIPTION" CONTENT="������ 100%, �����, ������ ������, �����ߴ�����, �ᳪ��,������ᳪ��  ">
<META NAME="KEYWORDS" CONTENT="������ 100%, �����, ������ ������, �����ߴ�����, �ᳪ��,������ᳪ�� ">
<script type="text/javascript">
// �ڹٽ�ũ��Ʈ���� ����ϴ� �������� ����
var g4_path      = ".";
var g4_bbs       = "bbs";
var g4_bbs_img   = "img";
var g4_url       = "http://www.momsis.co.kr";
var g4_is_member = "";
var g4_is_admin  = "";
var g4_bo_table  = "";
var g4_sca       = "";
var g4_charset   = "euc-kr";
var g4_cookie_domain = "";
var g4_is_gecko  = navigator.userAgent.toLowerCase().indexOf("gecko") != -1;
var g4_is_ie     = navigator.userAgent.toLowerCase().indexOf("msie") != -1;
</script>
<script type="text/javascript" src="./js/jquery-1.4.2.min.js"></script>
<script type="text/javascript" src="./js/common.js"></script>
<body topmargin="0" leftmargin="0" >
<a name="g4_head"></a>

<meta http-equiv="Content-Type" content="text/html; charset=euc-kr"><meta http-equiv="Content-Type" content="text/html; charset=euc-kr">
<table width="100%" height="373"  border="0" cellpadding="0" cellspacing="0">
  <tr>
    <td valign="top" style="background-image:url(/main/sub_back.jpg); background-repeat:no-repeat ; background-position:center top;" ><table width="1000" border="0" align="center" cellpadding="0" cellspacing="0">
        <tr>
          <td><meta http-equiv="Content-Type" content="text/html; charset=euc-kr">
<div style="position:relative; z-index:1; left: 0px; top: 0px; width: 100;">
        <div id="Layer1132" style="position:absolute; width:599px; height:27px; z-index:2; left: 328px; top: 2px; visibility: visible;">
          <div align="right">
                        <!-- �α��� ���� -->
            <a href="./bbs/login.php?url=%2Findex.php">�α���</a> | <a href="./bbs/register.php">ȸ������</a> |
                      <a href="/index.php"> ����ȭ��</a> | <a href="javascript:addfavorites()">���ã��</a> </div>
  </div>
</div>              <script src="/sub_a.js"></script></td>
        </tr>
    </table></td>
  </tr>
</table>
<meta http-equiv="Content-Type" content="text/html; charset=euc-kr">
<table width="936" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td height="30">&nbsp;</td>
  </tr>
</table>
<table width="936" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td width="200" valign="top"><meta http-equiv="Content-Type" content="text/html; charset=euc-kr">

<script language="JavaScript" type="text/JavaScript">
<!--



function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}
//-->
</script>
<body>
<table width="200" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td><img src="/main/z.gif" width="200" height="120"></td>
  </tr>
  <tr>
    <td><script src="/main_l.js"></script></td>
  </tr>
  <tr>
    <td><a href="/a4.php"><img src="main/e.gif" width="200" height="80" border="0"></a></td>
  </tr>
</table>
&nbsp;</td>
    <td width="10">&nbsp;</td>
    <td width="726" valign="top"><table width="726" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td width="363"><a href="/bbs/board.php?bo_table=e3"><img src="main/a1.gif" width="363" height="30" border="0"></a></td>
        <td width="363"><a href="/bbs/board.php?bo_table=e1"><img src="main/a2.gif" width="363" height="30" border="0"></a></td>
      </tr>
      <tr valign="top">
        <td><table width="100%"  border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td width="5%">&nbsp;</td>
            <td width="91%">
<style>
.title a:link {font-family:����; font-size:9pt; color:#333333; text-decoration:none;}
.title a:visited {font-family:����; font-size:9pt; color:#333333; text-decoration:none;}
.title a:active {font-family:����; font-size:9pt; color:#333333; text-decoration:none;}
.title a:hover {font-family:����; font-size:9pt; color:#ff6600; text-decoration:underline;}
</style>
            <TABLE cellSpacing=0 cellPadding=0 width="100%" border=0>
                            <TR>
                <TD></TD></TR>
              <TR>
                <TD style="PADDING-LEFT: 3px" vAlign=center height=25>
                 <IMG src='./skin/latest/sygnus/img/dot.gif' border=0>&nbsp;[2012-12-28]&nbsp;<a href='./bbs/board.php?bo_table=e3&wr_id=1'>Ȩ������ ���� �غ����Դϴ�.</a> </TD></TR>
<TR>
                <TD background=./skin/latest/sygnus/img/line.gif height=1></TD></TR>

              
              <TR>
                <TD></TD></TR>
              </TABLE></td>
            <td width="4%">&nbsp;</td>
          </tr>
        </table></td>
        <td><table width="100%"  border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td width="5%">&nbsp;</td>
            <td width="91%">
<style>
.title a:link {font-family:����; font-size:9pt; color:#333333; text-decoration:none;}
.title a:visited {font-family:����; font-size:9pt; color:#333333; text-decoration:none;}
.title a:active {font-family:����; font-size:9pt; color:#333333; text-decoration:none;}
.title a:hover {font-family:����; font-size:9pt; color:#ff6600; text-decoration:underline;}
</style>
            <TABLE cellSpacing=0 cellPadding=0 width="100%" border=0>
                            <TR>
                <TD></TD></TR>
              <TR>
                <TD style="PADDING-LEFT: 3px" vAlign=center height=25>
                 <IMG src='./skin/latest/sygnus/img/dot.gif' border=0>&nbsp;[2012-12-28]&nbsp;<a href='./bbs/board.php?bo_table=e1&wr_id=12'>��� ������ G ��ũ ���� �ο���</a> </TD></TR>
<TR>
                <TD background=./skin/latest/sygnus/img/line.gif height=1></TD></TR>
              <TR>
                <TD></TD></TR>
              <TR>
                <TD style="PADDING-LEFT: 3px" vAlign=center height=25>
                 <IMG src='./skin/latest/sygnus/img/dot.gif' border=0>&nbsp;[2012-12-28]&nbsp;<a href='./bbs/board.php?bo_table=e1&wr_id=11'>ģȯ�� ��깰 ������</a> </TD></TR>
<TR>
                <TD background=./skin/latest/sygnus/img/line.gif height=1></TD></TR>
              <TR>
                <TD></TD></TR>
              <TR>
                <TD style="PADDING-LEFT: 3px" vAlign=center height=25>
                 <IMG src='./skin/latest/sygnus/img/dot.gif' border=0>&nbsp;[2012-12-28]&nbsp;<a href='./bbs/board.php?bo_table=e1&wr_id=10'>��ǥ�����</a> </TD></TR>
<TR>
                <TD background=./skin/latest/sygnus/img/line.gif height=1></TD></TR>
              <TR>
                <TD></TD></TR>
              <TR>
                <TD style="PADDING-LEFT: 3px" vAlign=center height=25>
                 <IMG src='./skin/latest/sygnus/img/dot.gif' border=0>&nbsp;[2012-12-27]&nbsp;<a href='./bbs/board.php?bo_table=e1&wr_id=9'>����������޹�ħ</a> </TD></TR>
<TR>
                <TD background=./skin/latest/sygnus/img/line.gif height=1></TD></TR>
              <TR>
                <TD></TD></TR>
              <TR>
                <TD style="PADDING-LEFT: 3px" vAlign=center height=25>
                 <IMG src='./skin/latest/sygnus/img/dot.gif' border=0>&nbsp;[2012-12-27]&nbsp;<a href='./bbs/board.php?bo_table=e1&wr_id=8'>ȸ�����</a> </TD></TR>
<TR>
                <TD background=./skin/latest/sygnus/img/line.gif height=1></TD></TR>

              
              <TR>
                <TD></TD></TR>
              </TABLE></td>
            <td width="4%">&nbsp;</td>
          </tr>
        </table></td>
      </tr>
    </table>
      <table width="100%"  border="0" cellspacing="0" cellpadding="0">
        <tr>
          <td colspan="3"><img src="main/b1.gif" width="726" height="16"></td>
        </tr>
        <tr>
          <td width="13" background="main/b2.gif"><img src="main/b2.gif" width="13" height="68"></td>
          <td width="698">
            <div align="right">
              <!-- �ü��ȳ� (c1) �ֽű� -->

<table width='95%' cellpadding='0' cellspacing='0' border='0' align='left'>

<tr><td align='center'>

<table width='70%'>
   <tr>
    <td width='<?=118?>' valign='top' align='center'>
        <table width='<?=118?>' border='0' cellpadding='0' cellspacing='0' align='center'>
	<tr>
            <td width='<?=118?>' height='5' align='center'></td>
	</tr>

        <tr>
            <td width='<?=118?>' height='<?=86?>' align='center'>
		<div style='width:<?=118?>px;height:<?=86?>px;border:1px solid #CCCCCC;padding:3px' align='center'>
		<a href='./bbs/board.php?bo_table=c1&wr_id=6'><img src='./data/file/c1/2040362810_DaGiIySt_20.jpg' width='118' height='86' border='0' align='absmiddle' title='����ȸ ����'></a>
		</div>
	    </td>
        </tr>

	<tr>
            <td width='<?=118?>' height='5' align='center'></td>
	</tr>

	<tr>
            <td width='<?=118?>' height='20' align='center'><a href='./bbs/board.php?bo_table=c1&wr_id=6'>����ȸ ����</a></td>
	</tr>
	</table>
    </td><td width=20>&nbsp;</td>    <td width='<?=118?>' valign='top' align='center'>
        <table width='<?=118?>' border='0' cellpadding='0' cellspacing='0' align='center'>
	<tr>
            <td width='<?=118?>' height='5' align='center'></td>
	</tr>

        <tr>
            <td width='<?=118?>' height='<?=86?>' align='center'>
		<div style='width:<?=118?>px;height:<?=86?>px;border:1px solid #CCCCCC;padding:3px' align='center'>
		<a href='./bbs/board.php?bo_table=c1&wr_id=5'><img src='./data/file/c1/2040362810_6bon30mQ_18.jpg' width='118' height='86' border='0' align='absmiddle' title='������ �������'></a>
		</div>
	    </td>
        </tr>

	<tr>
            <td width='<?=118?>' height='5' align='center'></td>
	</tr>

	<tr>
            <td width='<?=118?>' height='20' align='center'><a href='./bbs/board.php?bo_table=c1&wr_id=5'>������ �������</a></td>
	</tr>
	</table>
    </td><td width=20>&nbsp;</td>    <td width='<?=118?>' valign='top' align='center'>
        <table width='<?=118?>' border='0' cellpadding='0' cellspacing='0' align='center'>
	<tr>
            <td width='<?=118?>' height='5' align='center'></td>
	</tr>

        <tr>
            <td width='<?=118?>' height='<?=86?>' align='center'>
		<div style='width:<?=118?>px;height:<?=86?>px;border:1px solid #CCCCCC;padding:3px' align='center'>
		<a href='./bbs/board.php?bo_table=c1&wr_id=4'><img src='./data/file/c1/2040362810_FKgOTDtL_10.jpg' width='118' height='86' border='0' align='absmiddle' title='�ᳪ�� ��ô �� ���� �۾�����'></a>
		</div>
	    </td>
        </tr>

	<tr>
            <td width='<?=118?>' height='5' align='center'></td>
	</tr>

	<tr>
            <td width='<?=118?>' height='20' align='center'><a href='./bbs/board.php?bo_table=c1&wr_id=4'>�ᳪ�� ��ô �� ���� �۾�����</a></td>
	</tr>
	</table>
    </td><td width=20>&nbsp;</td>    <td width='<?=118?>' valign='top' align='center'>
        <table width='<?=118?>' border='0' cellpadding='0' cellspacing='0' align='center'>
	<tr>
            <td width='<?=118?>' height='5' align='center'></td>
	</tr>

        <tr>
            <td width='<?=118?>' height='<?=86?>' align='center'>
		<div style='width:<?=118?>px;height:<?=86?>px;border:1px solid #CCCCCC;padding:3px' align='center'>
		<a href='./bbs/board.php?bo_table=c1&wr_id=3'><img src='./data/file/c1/2040362810_flChtJoV_7.jpg' width='118' height='86' border='0' align='absmiddle' title='�ᳪ�� ��������Ȯ��'></a>
		</div>
	    </td>
        </tr>

	<tr>
            <td width='<?=118?>' height='5' align='center'></td>
	</tr>

	<tr>
            <td width='<?=118?>' height='20' align='center'><a href='./bbs/board.php?bo_table=c1&wr_id=3'>�ᳪ�� ��������Ȯ��</a></td>
	</tr>
	</table>
    </td><td width=20>&nbsp;</td>    <td width='<?=118?>' valign='top' align='center'>
        <table width='<?=118?>' border='0' cellpadding='0' cellspacing='0' align='center'>
	<tr>
            <td width='<?=118?>' height='5' align='center'></td>
	</tr>

        <tr>
            <td width='<?=118?>' height='<?=86?>' align='center'>
		<div style='width:<?=118?>px;height:<?=86?>px;border:1px solid #CCCCCC;padding:3px' align='center'>
		<a href='./bbs/board.php?bo_table=c1&wr_id=2'><img src='./data/file/c1/2040362810_643DJkRx_2.jpg' width='118' height='86' border='0' align='absmiddle' title='ȸ������'></a>
		</div>
	    </td>
        </tr>

	<tr>
            <td width='<?=118?>' height='5' align='center'></td>
	</tr>

	<tr>
            <td width='<?=118?>' height='20' align='center'><a href='./bbs/board.php?bo_table=c1&wr_id=2'>ȸ������</a></td>
	</tr>
	</table>
    </td></tr>

</table>
<div align="center"></div></td></tr>
</table>          </div></td>
          <td width="15" background="main/b3.gif"><img src="main/b3.gif" width="15" height="68"></td>
        </tr>
        <tr>
          <td colspan="3"><img src="main/b4.gif" width="726" height="16"></td>
        </tr>
    </table></td>
  </tr>
</table>
<meta http-equiv="Content-Type" content="text/html; charset=euc-kr">

<meta http-equiv="Content-Type" content="text/html; charset=euc-kr">
<table width="1000" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td><img src="/main/down.gif" width="1000" height="102" border="0" usemap="#shfadksa"></td>
  </tr>
</table>
<script type="text/javascript" src="./js/wrest.js"></script>

<!-- ��â ��� ����ϴ� iframe -->
<iframe width=0 height=0 name='hiddenframe' style='display:none;'></iframe>


</body>
</html>

<map name="shfadksa"> 
  <area shape="rect" coords="148,49,209,71" href="/adm/" onClick="blur();">
  <area shape="rect" coords="551,21,617,46" href="/bbs/board.php?bo_table=e1">
  <area shape="rect" coords="621,24,680,48" href="/bbs/board.php?bo_table=e2">
  <area shape="rect" coords="687,22,755,47" href="/bbs/board.php?bo_table=e3">
  <area shape="rect" coords="762,22,817,49" href="/bbs/board.php?bo_table=e1&wr_id=8">
  <area shape="rect" coords="819,20,911,47" href="/bbs/board.php?bo_table=e1&wr_id=9">
</map>
<script language="JavaScript" src="./js/shop.js"></script><Script language="JavaScript">
var favoriteurl="http://www.momsis.co.kr";
var favoritetitle="������ 100% ����� ������ ������ �����ߴ����� �ᳪ��";
function addfavorites(){
if (document.all)
window.external.AddFavorite(favoriteurl,favoritetitle)}
</script>