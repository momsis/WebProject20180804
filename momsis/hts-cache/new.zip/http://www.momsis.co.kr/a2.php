<!-- <!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"> -->
<html>
<head>
<meta http-equiv="content-type" content="text/html; charset=euc-kr">
<title>������ 100% ����� ������ ������ �����ߴ����� �ᳪ��</title>
<link rel="stylesheet" href="./style.css" type="text/css">
</head>
<META NAME="DESCRIPTION" CONTENT="������ 100%, �����, ������ ������, �����ߴ�����, �ᳪ��,������ᳪ��  ">
<META NAME="KEYWORDS" CONTENT="������ 100%, �����, ������ ������, �����ߴ�����, �ᳪ��,������ᳪ�� ">
<script type="text/javascript">
// �ڹٽ�ũ��Ʈ���� ����ϴ� �������� ����
var g4_path      = ".";
var g4_bbs       = "bbs";
var g4_bbs_img   = "img";
var g4_url       = "http://www.momsis.co.kr";
var g4_is_member = "";
var g4_is_admin  = "";
var g4_bo_table  = "";
var g4_sca       = "";
var g4_charset   = "euc-kr";
var g4_cookie_domain = "";
var g4_is_gecko  = navigator.userAgent.toLowerCase().indexOf("gecko") != -1;
var g4_is_ie     = navigator.userAgent.toLowerCase().indexOf("msie") != -1;
</script>
<script type="text/javascript" src="./js/jquery-1.4.2.min.js"></script>
<script type="text/javascript" src="./js/common.js"></script>
<body topmargin="0" leftmargin="0" >
<a name="g4_head"></a>

<meta http-equiv="Content-Type" content="text/html; charset=euc-kr"><meta http-equiv="Content-Type" content="text/html; charset=euc-kr">
<table width="100%" height="373"  border="0" cellpadding="0" cellspacing="0">
  <tr>
    <td valign="top" style="background-image:url(/main/sub_back.jpg); background-repeat:no-repeat ; background-position:center top;" ><table width="1000" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td><meta http-equiv="Content-Type" content="text/html; charset=euc-kr">
<div style="position:relative; z-index:1; left: 0px; top: 0px; width: 100;">
        <div id="Layer1132" style="position:absolute; width:599px; height:27px; z-index:2; left: 328px; top: 2px; visibility: visible;">
          <div align="right">
                        <!-- �α��� ���� -->
            <a href="./bbs/login.php?url=%2Fa2.php">�α���</a> | <a href="./bbs/register.php">ȸ������</a> |
                      <a href="/index.php"> ����ȭ��</a> | <a href="javascript:addfavorites()">���ã��</a> </div>
  </div>
</div>            <script src="/sub_a.js"></script></td>
      </tr>
    </table></td>
  </tr>
</table>
<meta http-equiv="Content-Type" content="text/html; charset=euc-kr">
<table width="936" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr valign="top">
    <td width="200" height="300"><meta http-equiv="Content-Type" content="text/html; charset=euc-kr">

<script language="JavaScript" type="text/JavaScript">
<!--



function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}
//-->
</script>
<body><table width="200" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td colspan="3"><img src="/title2/head_1.gif" width="200" height="86"></td>
  </tr>
  <tr>
    <td width="13" background="/title2/l_head_1.gif"><img src="/title2/l_head_1.gif" width="13" height="92"></td>
    <td width="173" valign="top" background="/title2/l_head_back.gif"><table width="100%"  border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td height="25"><img src="/title2/2.gif" width="20" height="13" align="absmiddle"><a href="/a1.php">�λ縻</a></td>
      </tr>
      <tr>
        <td background="/title2/1.gif"><img src="/title2/1.gif" width="48" height="3"></td>
      </tr>      <tr>
        <td height="25"><img src="/title2/2.gif" width="20" height="13" align="absmiddle"><a href="/a2.php">����</a></td>
      </tr>
      <tr>
        <td background="/title2/1.gif"><img src="/title2/1.gif" width="48" height="3"></td>
      </tr>
      <tr>
        <td height="25"><img src="/title2/2.gif" width="20" height="13" align="absmiddle"><a href="/a3.php">������</a></td>
      </tr>
      <tr>
        <td background="/title2/1.gif"><img src="/title2/1.gif" width="48" height="3"></td>
      </tr>
      <tr>
        <td height="25"><img src="/title2/2.gif" width="20" height="13" align="absmiddle"><a href="/a4.php">ã�ƿ��ô±�</a></td>
      </tr>
      <tr>
        <td background="/title2/1.gif"><img src="/title2/1.gif" width="48" height="3"></td>
      </tr>
	        <tr>
        <td height="25">&nbsp;</td>
      </tr>
  
    </table></td>
    <td width="14" background="/title2/l_head_2.gif"><img src="/title2/l_head_2.gif" width="14" height="92"></td>
  </tr>
  <tr>
    <td colspan="3"><img src="/title2/l_head_3.gif" width="200" height="16"></td>
  </tr>
</table>
<meta http-equiv="Content-Type" content="text/html; charset=euc-kr">

<script language="JavaScript" type="text/JavaScript">
<!--



function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}
//-->
</script>
<body>
<table width="200" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td><img src="/main/z.gif" width="200" height="120"></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
  </tr>
</table>
&nbsp;</td>
    <td width="10">&nbsp;</td>
    <td width="726"><table width="100%"  border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td><img src="/title/a2.gif" width="726" height="50"></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td><table width="683" border="0" cellspacing="0" cellpadding="3">
          <tr>
            <td colspan="3"><img src="hi/line.gif" width="100%" height="5"></td>
          </tr>
          <tr>
            <td width="82" height="25"><b>2002</b></td>
            <td width="50">08.01</td>
            <td width="500"> ����ᳪ������ ( �ϳ��� ǳ�굿 ) </td>
          </tr>
          <tr>
            <td colspan="3"><img src="hi/line3.gif" width="683" height="6"></td>
          </tr>
          <tr>
            <td height="25">&nbsp;</td>
            <td>11.05</td>
            <td><p> ģȯ���깰���� ( ������ᳪ�� )- ������깰ǰ�� ������ </p></td>
          </tr>
          <tr>
            <td colspan="3"><img src="hi/line3.gif" width="683" height="6"></td>
          </tr>
          <tr>
            <td height="25"><b>2008</b></td>
            <td>05.29</td>
            <td><p> �� ���ְ����ذ� </p></td>
          </tr>
          <tr>
            <td colspan="3"><img src="hi/line2.gif" width="100%" height="6"></td>
          </tr>
          <tr>
            <td height="25">&nbsp;</td>
            <td>07.01</td>
            <td><p> ���ְ������� ���� </p></td>
          </tr>
          <tr>
            <td colspan="3"><img src="hi/line2.gif" width="100%" height="6"></td>
          </tr>
          <tr>
            <td height="25">&nbsp;</td>
            <td>12.05</td>
            <td><p> OXYFOOD �� ȸ��� ���� </p></td>
          </tr>
          <tr>
            <td colspan="3"><img src="hi/line2.gif" width="100%" height="6"></td>
          </tr>
          <tr>
            <td height="25"><b>2009</b></td>
            <td>03.27</td>
            <td><p> �����ߴ����� ��ǥ �� ����ǥ��� </p></td>
          </tr>
          <tr>
            <td colspan="3"><img src="hi/line2.gif" width="100%" height="6"></td>
          </tr>
          <tr>
            <td height="25">&nbsp;</td>
            <td>07.01</td>
            <td><p> G ��ũ���� - ��⵵���� </p></td>
          </tr>
          <tr>
            <td colspan="3"><img src="hi/line2.gif" width="100%" height="6"></td>
          </tr>
          <tr>
            <td height="25"><b>2012</b></td>
            <td>07.20</td>
            <td><p> ���ȸ����� �߾����ߴ����� ���� </p></td>
          </tr>
          <tr>
            <td colspan="3"><img src="hi/line2.gif" width="100%" height="6"></td>
          </tr>
          <tr>
            <td colspan="3">&nbsp;</td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td><table width="683" border="0" cellspacing="0" cellpadding="3">
          <tr>
            <td colspan="2"><img src="hi/line.gif" width="100%" height="5"></td>
          </tr>
          <tr>
            <td width="332" height="25"><p><b>ģȯ���깰(�����)���� : </b></p></td>
            <td width="345"><p><font color="">������깰ǰ�������� </font>��10-23-3-98ȣ </p></td>
          </tr>
          <tr>
            <td colspan="2"><img src="hi/line3.gif" width="683" height="6"></td>
          </tr>
          <tr>
            <td height="25"><p><b>����ǥ���(����ᳪ��) : </b></p></td>
            <td><p><font color="">��� �� 0099195ȣ</font></p></td>
          </tr>
          <tr>
            <td colspan="2"><img src="hi/line3.gif" width="683" height="6"></td>
          </tr>		  
          <tr>
            <td height="25"><font color="#000000"><strong>��⵵���� ���� G ��ũ ȹ�� :</strong></font></td>
            <td><font color="#000000"> 09-103-006 </font> </td>
          </tr>
          <tr>
            <td colspan="2"><p><img src="hi/line.gif" width="100%" height="5"></p>
                <p>&nbsp;</p>
                <p>&nbsp;</p>
                <p>&nbsp;</p></td>
          </tr>
        </table></td>
      </tr>
    </table></td>
  </tr>
</table>
<meta http-equiv="Content-Type" content="text/html; charset=euc-kr">
<table width="1000" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td><img src="/main/down.gif" width="1000" height="102" border="0" usemap="#shfadksa"></td>
  </tr>
</table>
<script type="text/javascript" src="./js/wrest.js"></script>

<!-- ��â ��� ����ϴ� iframe -->
<iframe width=0 height=0 name='hiddenframe' style='display:none;'></iframe>


</body>
</html>

<map name="shfadksa"> 
  <area shape="rect" coords="148,49,209,71" href="/adm/" onClick="blur();">
  <area shape="rect" coords="551,21,617,46" href="/bbs/board.php?bo_table=e1">
  <area shape="rect" coords="621,24,680,48" href="/bbs/board.php?bo_table=e2">
  <area shape="rect" coords="687,22,755,47" href="/bbs/board.php?bo_table=e3">
  <area shape="rect" coords="762,22,817,49" href="/bbs/board.php?bo_table=e1&wr_id=8">
  <area shape="rect" coords="819,20,911,47" href="/bbs/board.php?bo_table=e1&wr_id=9">
</map>
<script language="JavaScript" src="./js/shop.js"></script><Script language="JavaScript">
var favoriteurl="http://www.momsis.co.kr";
var favoritetitle="������ 100% ����� ������ ������ �����ߴ����� �ᳪ��";
function addfavorites(){
if (document.all)
window.external.AddFavorite(favoriteurl,favoritetitle)}
</script>