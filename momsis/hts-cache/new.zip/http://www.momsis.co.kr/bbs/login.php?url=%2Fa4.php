<!-- <!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"> -->
<html>
<head>
<meta http-equiv="content-type" content="text/html; charset=euc-kr">
<title>�α���</title>
<link rel="stylesheet" href="../style.css" type="text/css">
</head>
<META NAME="DESCRIPTION" CONTENT="������ 100%, �����, ������ ������, �����ߴ�����, �ᳪ��,������ᳪ��  ">
<META NAME="KEYWORDS" CONTENT="������ 100%, �����, ������ ������, �����ߴ�����, �ᳪ��,������ᳪ�� ">
<script type="text/javascript">
// �ڹٽ�ũ��Ʈ���� ����ϴ� �������� ����
var g4_path      = "..";
var g4_bbs       = "bbs";
var g4_bbs_img   = "img";
var g4_url       = "http://www.momsis.co.kr";
var g4_is_member = "";
var g4_is_admin  = "";
var g4_bo_table  = "";
var g4_sca       = "";
var g4_charset   = "euc-kr";
var g4_cookie_domain = "";
var g4_is_gecko  = navigator.userAgent.toLowerCase().indexOf("gecko") != -1;
var g4_is_ie     = navigator.userAgent.toLowerCase().indexOf("msie") != -1;
</script>
<script type="text/javascript" src="../js/jquery-1.4.2.min.js"></script>
<script type="text/javascript" src="../js/common.js"></script>
<body topmargin="0" leftmargin="0" >
<a name="g4_head"></a>

<meta http-equiv="Content-Type" content="text/html; charset=euc-kr"><meta http-equiv="Content-Type" content="text/html; charset=euc-kr">
<table width="100%" height="373"  border="0" cellpadding="0" cellspacing="0">
  <tr>
    <td valign="top" style="background-image:url(/main/sub_back.jpg); background-repeat:no-repeat ; background-position:center top;" ><table width="1000" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td><meta http-equiv="Content-Type" content="text/html; charset=euc-kr">
<div style="position:relative; z-index:1; left: 0px; top: 0px; width: 100;">
        <div id="Layer1132" style="position:absolute; width:599px; height:27px; z-index:2; left: 328px; top: 2px; visibility: visible;">
          <div align="right">
                        <!-- �α��� ���� -->
            <a href="../bbs/login.php?url=%2Fa4.php">�α���</a> | <a href="../bbs/register.php">ȸ������</a> |
                      <a href="/index.php"> ����ȭ��</a> | <a href="javascript:addfavorites()">���ã��</a> </div>
  </div>
</div>            <script src="/sub_a.js"></script></td>
      </tr>
    </table></td>
  </tr>
</table>
<meta http-equiv="Content-Type" content="text/html; charset=euc-kr">
<table width="936" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr valign="top">
    <td width="200" height="300"><meta http-equiv="Content-Type" content="text/html; charset=euc-kr">

<script language="JavaScript" type="text/JavaScript">
<!--



function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}
//-->
</script>
<body><table width="200" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td colspan="3"><img src="/title2/head_1.gif" width="200" height="86"></td>
  </tr>
  <tr>
    <td width="13" background="/title2/l_head_1.gif"><img src="/title2/l_head_1.gif" width="13" height="92"></td>
    <td width="173" valign="top" background="/title2/l_head_back.gif"><table width="100%"  border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td height="25"><img src="/title2/2.gif" width="20" height="13" align="absmiddle"><a href="/a1.php">�λ縻</a></td>
      </tr>
      <tr>
        <td background="/title2/1.gif"><img src="/title2/1.gif" width="48" height="3"></td>
      </tr>      <tr>
        <td height="25"><img src="/title2/2.gif" width="20" height="13" align="absmiddle"><a href="/a2.php">����</a></td>
      </tr>
      <tr>
        <td background="/title2/1.gif"><img src="/title2/1.gif" width="48" height="3"></td>
      </tr>
      <tr>
        <td height="25"><img src="/title2/2.gif" width="20" height="13" align="absmiddle"><a href="/a3.php">������</a></td>
      </tr>
      <tr>
        <td background="/title2/1.gif"><img src="/title2/1.gif" width="48" height="3"></td>
      </tr>
      <tr>
        <td height="25"><img src="/title2/2.gif" width="20" height="13" align="absmiddle"><a href="/a4.php">ã�ƿ��ô±�</a></td>
      </tr>
      <tr>
        <td background="/title2/1.gif"><img src="/title2/1.gif" width="48" height="3"></td>
      </tr>
	        <tr>
        <td height="25">&nbsp;</td>
      </tr>
  
    </table></td>
    <td width="14" background="/title2/l_head_2.gif"><img src="/title2/l_head_2.gif" width="14" height="92"></td>
  </tr>
  <tr>
    <td colspan="3"><img src="/title2/l_head_3.gif" width="200" height="16"></td>
  </tr>
</table>
<meta http-equiv="Content-Type" content="text/html; charset=euc-kr">

<script language="JavaScript" type="text/JavaScript">
<!--



function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}
//-->
</script>
<body>
<table width="200" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td><img src="/main/z.gif" width="200" height="120"></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
  </tr>
</table>
&nbsp;</td>
    <td width="10">&nbsp;</td>
    <td width="726">
<meta http-equiv="Content-Type" content="text/html; charset=euc-kr">
<script type="text/javascript" src="../js/capslock.js"></script>

<form name="flogin" method="post" onsubmit="return flogin_submit(this);" autocomplete="off">
<input type="hidden" name="url" value='%2Fa4.php'>

<table width="668" border="0" align="center" cellpadding="0" cellspacing="0">
<tr>
    <td height="26"></td>
    <td width="628"></td>
    <td width="20"></td>
</tr>
<tr>
    <td width="20" height="2"></td>
    <td width="628"></td>
    <td width="20"></td>
</tr>
<tr>
    <td width="20" height="48"></td>
    <td width="628" align="right">&nbsp;</td>
    <td width="20"></td>
</tr>
<tr>
    <td width="20" height="223"></td>
    <td width="628" align="center">
        <table width="460" border="0" cellspacing="0" cellpadding="0">
        <tr>
            <td width="460" height="223" align="center">
                <table width="350" border="0" cellpadding="0" cellspacing="0">
                <tr>
                    <td width="250">
                        <table width="250" border="0" cellpadding="0" cellspacing="0">
                        <tr>
                            <td width="10"><img src="../skin/member/basic/img/icon.gif" width="3" height="3"></td>
                            <td width="90" height="26"><b>���̵�</b></td>
                            <td width="150"><INPUT type=text class=ed maxLength=20 size=15 name=mb_id itemname="���̵�" required minlength="2"></td>
                        </tr>
                        <tr>
                            <td><img src="../skin/member/basic/img/icon.gif" width="3" height="3"></td>
                            <td height="26"><b>�н�����</b></td>
                            <td><INPUT type=password class=ed maxLength=20 size=15 name=mb_password id="login_mb_password" itemname="�н�����" required onkeypress="check_capslock(event, 'login_mb_password');"></td>
                        </tr>
                        <tr>
                            <td><img src="../skin/member/basic/img/icon.gif" width="3" height="3"></td>
                            <td height="26"><b>�ڵ��α���</b></td>
                            <td><INPUT onclick="if (this.checked) { if (confirm('�ڵ��α����� ����Ͻø� �������� ȸ�����̵�� �н����带 �Է��Ͻ� �ʿ䰡 �����ϴ�.\n\n\������ҿ����� ���������� ����� �� ������ ����� �����Ͽ� �ֽʽÿ�.\n\n�ڵ��α����� ����Ͻðڽ��ϱ�?')) { this.checked = true; } else { this.checked = false;} }" type=checkbox name=auto_login>
                                <b>���</b></td>
                        </tr>
                        </table>
                    </td>
                    <td width="100" valign="top"><INPUT type=image width="65" height="52" src="../skin/member/basic/img/btn_login.gif" border=0></td>
                </tr>
                <tr>
                    <td height="5" colspan="2"></td>
                </tr>
                <tr>
                    <td height="1" background="../skin/member/basic/img/dot_line.gif" colspan="2"></td>
                </tr>
                <tr>
                    <td height="5" colspan="2"></td>
                </tr>
                <tr>
                    <td height="26" colspan="2"><img src="../skin/member/basic/img/icon.gif" width="3" height="3"> ���� ȸ���� �ƴϽʴϱ�?&nbsp;&nbsp;&nbsp;&nbsp;<a href="./register.php"><img width="72" height="20" src="../skin/member/basic/img/btn_register.gif" border=0 align="absmiddle"></a></td>
                </tr>
                <tr>
                    <!-- <td height="26" colspan="2"><img src="../skin/member/basic/img/icon.gif" width="3" height="3"> ���̵�/�н����带 �����̽��ϱ�?&nbsp;&nbsp;&nbsp;&nbsp;<a href="javascript:;" onclick="win_password_forget('./password_forget.php');"><img src="../skin/member/basic/img/btn_password_forget.gif" width="108" height="20" border=0 align="absmiddle"></td> -->
                    <td height="26" colspan="2"><img src="../skin/member/basic/img/icon.gif" width="3" height="3"> ���̵�/�н����带 �����̽��ϱ�?&nbsp;&nbsp;&nbsp;&nbsp;<a href="javascript:;" onclick="win_password_lost();"><img src="../skin/member/basic/img/btn_password_forget.gif" width="108" height="20" border=0 align="absmiddle"></td>
                </tr>
            </table></td>
        </tr>
      </table></td>
    <td width="20"></td>
</tr>
<tr>
    <td width="20" height="1"></td>
    <td width="628" bgcolor="#F0F0F0"></td>
    <td width="20"></td>
</tr>
<tr>
    <td height="20" colspan="3"></td>
</tr>
</table>

</form>

<script type='text/javascript'>
document.flogin.mb_id.focus();

function flogin_submit(f)
{
    f.action = '../bbs/login_check.php';
    return true;
}
</script>
&nbsp;</td>
  </tr>
</table>
<meta http-equiv="Content-Type" content="text/html; charset=euc-kr">
<table width="1000" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td><img src="/main/down.gif" width="1000" height="102" border="0" usemap="#shfadksa"></td>
  </tr>
</table>
<script type="text/javascript" src="../js/wrest.js"></script>

<!-- ��â ��� ����ϴ� iframe -->
<iframe width=0 height=0 name='hiddenframe' style='display:none;'></iframe>


</body>
</html>

<map name="shfadksa"> 
  <area shape="rect" coords="148,49,209,71" href="/adm/" onClick="blur();">
  <area shape="rect" coords="551,21,617,46" href="/bbs/board.php?bo_table=e1">
  <area shape="rect" coords="621,24,680,48" href="/bbs/board.php?bo_table=e2">
  <area shape="rect" coords="687,22,755,47" href="/bbs/board.php?bo_table=e3">
  <area shape="rect" coords="762,22,817,49" href="/bbs/board.php?bo_table=e1&wr_id=8">
  <area shape="rect" coords="819,20,911,47" href="/bbs/board.php?bo_table=e1&wr_id=9">
</map>
<script language="JavaScript" src="../js/shop.js"></script><Script language="JavaScript">
var favoriteurl="http://www.momsis.co.kr";
var favoritetitle="������ 100% ����� ������ ������ �����ߴ����� �ᳪ��";
function addfavorites(){
if (document.all)
window.external.AddFavorite(favoriteurl,favoritetitle)}
</script>